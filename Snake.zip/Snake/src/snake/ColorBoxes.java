/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


import java.applet.Applet;
import java.awt.*;

/**
 *
 * @author Davis
 */
public class ColorBoxes extends Applet {

   public void paint(Graphics g) {
		 int rval, gval, bval;
		
		for (int j = 30; j < (this.size().height -25); j += 30)
		 for (int i = 5; i < (this.size().width -25); i+= 30) {
		 rval = (int)Math.floor(Math.random() * 256);
		 gval = (int)Math.floor(Math.random() * 256);
		 bval = (int)Math.floor(Math.random() * 256);
		
		 g.setColor(new Color(rval,gval,bval));
		 g.fillRect(i,j,25,25);
		 g.setColor(Color.black);
		 g.drawRect(i-1,j-1,25,25);
		 }
		 }
}
